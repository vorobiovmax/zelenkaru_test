-- Adminer 4.8.1 MySQL 8.0.27 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `real_id` int unsigned NOT NULL,
  `user_name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `user_phone` varchar(15) COLLATE utf8mb4_bin NOT NULL,
  `warehouse_id` int unsigned NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint NOT NULL,
  `items_count` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `real_id` (`real_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

TRUNCATE `orders`;

-- 2022-06-27 02:45:53
